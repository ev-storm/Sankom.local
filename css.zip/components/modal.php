<div class="modal-con">
	<div class="modal">
		<form class="call-back-form form" action="#" method="POST">
			<input  class="input-name" type="text" name="Имя" placeholder="Ваше имя">
			<input class="input-tel" type="tel" name="Телефон" placeholder="Телефон">
			<button class="btn btn-modal">Получить каталог</button>
		</form>
	</div>
</div>